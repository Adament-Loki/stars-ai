```
Stars! AI Observer Report - Turn 100 / Year 2500
==================================================================

EXECUTIVE SUMMARY
-----------------
The game remains competitive; P5 Loraxoid currently has a narrow lead. Observer score gap over second place: 8.8%.
Yes - fighting/conquest has begun. 2 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 22 planets, pop 118,582, 23657 factories, 423 ships / 0 fleet mass, tech total 86, 20 starbases.
2. P6 Berserker [Alternate Reality] - 184 planets, pop 833,454, 56 factories, 1850 ships / 0 fleet mass, tech total 117, 184 starbases.
3. P2 Kilingons [War Monger / Balanced] - 33 planets, pop 78,717, 6993 factories, 38 ships / 0 fleet mass, tech total 42, 15 starbases.
4. P7 Rush'n [Inner Strength] - 11 planets, pop 52,446, 6875 factories, 89 ships / 0 fleet mass, tech total 81, 7 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 22 planets, pop 55,009, 4547 factories, 66 ships / 0 fleet mass, tech total 81, 6 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 21 planets, pop 44,970, 4389 factories, 78 ships / 0 fleet mass, tech total 46, 8 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 10 planets, pop 22,454, 2442 factories, 68 ships / 0 fleet mass, tech total 41, 6 starbases.

CHANGE SINCE TURN 95
-----------------------------
P5: planets -1, population +6,928, factories +2404, ships +31, fleet mass +0, tech total +8.
P6: planets +8, population +149,005, factories +56, ships +340, fleet mass +0, tech total +10.
P2: planets +1, population +8,714, factories +1243, ships -2, fleet mass +0, tech total +2.
P7: planets +1, population +2,908, factories +408, ships -1, fleet mass +0, tech total +4.
P3: planets +1, population +5,047, factories +392, ships +17, fleet mass +0, tech total +4.
P1: planets -2, population +3,820, factories +629, ships -7, fleet mass +0, tech total +1.
P4: planets -1, population -1,260, factories -17, ships -4, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- P2 captured planet #59 from P1.
- P3 captured planet #74 from P1.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 184 planets.
- Population: P6 with 833,454.
- Industry: P5 with 23657 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 117.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P2 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
