```
Stars! AI Observer Report - Turn 85 / Year 2485
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker is leading. Observer score gap over second place: 15.9%.
Yes - fighting/conquest has begun. 3 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 157 planets, pop 405,076, 0 factories, 965 ships / 0 fleet mass, tech total 92, 157 starbases.
2. P5 Loraxoid [Super Stealth] - 25 planets, pop 99,564, 12007 factories, 250 ships / 0 fleet mass, tech total 69, 19 starbases.
3. P7 Rush'n [Inner Strength] - 10 planets, pop 45,163, 5895 factories, 81 ships / 0 fleet mass, tech total 70, 6 starbases.
4. P2 Kilingons [War Monger / Balanced] - 34 planets, pop 53,531, 3664 factories, 35 ships / 0 fleet mass, tech total 37, 8 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 16 planets, pop 37,360, 3114 factories, 52 ships / 0 fleet mass, tech total 69, 6 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 26 planets, pop 33,419, 2828 factories, 97 ships / 0 fleet mass, tech total 41, 5 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 12 planets, pop 21,995, 2050 factories, 77 ships / 0 fleet mass, tech total 37, 5 starbases.

CHANGE SINCE TURN 80
-----------------------------
P6: planets +12, population +124,544, factories +0, ships +118, fleet mass +0, tech total +5.
P5: planets +2, population +13,543, factories +3768, ships +48, fleet mass +0, tech total +2.
P7: planets -2, population +2,717, factories +458, ships +26, fleet mass +0, tech total +1.
P2: planets +0, population +8,243, factories +669, ships +3, fleet mass +0, tech total +1.
P3: planets -2, population +3,186, factories +421, ships +0, fleet mass +0, tech total +4.
P1: planets +0, population +2,263, factories +247, ships +2, fleet mass +0, tech total +2.
P4: planets +1, population +2,209, factories +335, ships +6, fleet mass +0, tech total +3.

WAR & CONTACT
-------------
- P3 captured planet #87 from P1.
- P6 captured planet #285 from P3.
- P1 captured planet #87 from P3.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 157 planets.
- Population: P6 with 405,076.
- Industry: P5 with 12007 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 92.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
