```
Stars! AI Observer Report - Turn 60 / Year 2460
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 87.3%.
Yes - fighting/conquest has begun. 1 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 103 planets, pop 77,367, 0 factories, 293 ships / 0 fleet mass, tech total 66, 103 starbases.
2. P5 Loraxoid [Super Stealth] - 24 planets, pop 25,244, 2761 factories, 139 ships / 0 fleet mass, tech total 54, 3 starbases.
3. P7 Rush'n [Inner Strength] - 8 planets, pop 29,191, 2714 factories, 34 ships / 0 fleet mass, tech total 55, 5 starbases.
4. P1 Humanoid [Jack of All Trades / Balanced] - 22 planets, pop 19,381, 1423 factories, 85 ships / 0 fleet mass, tech total 34, 3 starbases.
5. P2 Kilingons [War Monger / Balanced] - 26 planets, pop 22,299, 1415 factories, 30 ships / 0 fleet mass, tech total 31, 2 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 16 planets, pop 19,605, 1398 factories, 48 ships / 0 fleet mass, tech total 50, 2 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 12 planets, pop 11,386, 635 factories, 68 ships / 0 fleet mass, tech total 28, 3 starbases.

CHANGE SINCE TURN 55
-----------------------------
P6: planets +13, population +18,492, factories +0, ships +104, fleet mass +0, tech total +5.
P5: planets +4, population +5,639, factories +228, ships +16, fleet mass +0, tech total +3.
P7: planets +0, population +4,226, factories +1057, ships +5, fleet mass +0, tech total +4.
P1: planets +4, population +3,671, factories +255, ships +18, fleet mass +0, tech total +1.
P2: planets +2, population +758, factories +304, ships -1, fleet mass +0, tech total +1.
P3: planets +2, population +2,451, factories +171, ships -1, fleet mass +0, tech total +2.
P4: planets +2, population +1,774, factories +108, ships -5, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- P3 captured planet #110 from P1.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 103 planets.
- Population: P6 with 77,367.
- Industry: P5 with 2761 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 66.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
