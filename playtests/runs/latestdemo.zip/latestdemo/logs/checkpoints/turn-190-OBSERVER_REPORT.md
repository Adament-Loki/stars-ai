```
Stars! AI Observer Report - Turn 190 / Year 2590
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid has a clear lead. Observer score gap over second place: 38.0%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 28 planets, pop 103,630, 35083 factories, 507 ships / 0 fleet mass, tech total 153, 19 starbases.
2. P6 Berserker [Alternate Reality] - 177 planets, pop 4,695,230, 56 factories, 2640 ships / 0 fleet mass, tech total 156, 177 starbases.
3. P1 Humanoid [Jack of All Trades / Balanced] - 15 planets, pop 79,719, 15337 factories, 57 ships / 0 fleet mass, tech total 79, 8 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 7 planets, pop 21,375, 7133 factories, 49 ships / 0 fleet mass, tech total 118, 3 starbases.
5. P7 Rush'n [Inner Strength] - 2 planets, pop 5,951, 826 factories, 41 ships / 0 fleet mass, tech total 113, 1 starbases.
6. P2 Kilingons [War Monger / Balanced] - 1 planets, pop 8,462, 798 factories, 5 ships / 0 fleet mass, tech total 73, 1 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 0 planets, pop 0, 0 factories, 0 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 185
-----------------------------
P5: planets +6, population -11,292, factories +2744, ships -41, fleet mass +0, tech total +2.
P6: planets +0, population +82,868, factories +0, ships -535, fleet mass +0, tech total +0.
P1: planets +0, population -17,490, factories -1365, ships -7, fleet mass +0, tech total +0.
P3: planets -2, population -6,852, factories -1132, ships +4, fleet mass +0, tech total +1.
P7: planets +0, population +349, factories +62, ships +3, fleet mass +0, tech total +0.
P2: planets +0, population +183, factories +0, ships -6, fleet mass +0, tech total +0.
P4: planets +0, population +0, factories +0, ships +0, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 177 planets.
- Population: P6 with 4,695,230.
- Industry: P5 with 35083 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 156.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P4 has no planets and is effectively eliminated.

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
