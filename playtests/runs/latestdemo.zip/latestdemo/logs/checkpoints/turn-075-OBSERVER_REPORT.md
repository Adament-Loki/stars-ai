```
Stars! AI Observer Report - Turn 75 / Year 2475
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 69.2%.
Yes - fighting/conquest has begun. 2 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 137 planets, pop 191,381, 0 factories, 563 ships / 0 fleet mass, tech total 80, 137 starbases.
2. P5 Loraxoid [Super Stealth] - 23 planets, pop 68,030, 5121 factories, 196 ships / 0 fleet mass, tech total 65, 11 starbases.
3. P7 Rush'n [Inner Strength] - 9 planets, pop 39,187, 4910 factories, 53 ships / 0 fleet mass, tech total 65, 6 starbases.
4. P2 Kilingons [War Monger / Balanced] - 33 planets, pop 38,596, 2458 factories, 31 ships / 0 fleet mass, tech total 34, 7 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 20 planets, pop 29,741, 2332 factories, 52 ships / 0 fleet mass, tech total 61, 3 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 25 planets, pop 27,782, 2242 factories, 91 ships / 0 fleet mass, tech total 38, 3 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 11 planets, pop 17,539, 1462 factories, 61 ships / 0 fleet mass, tech total 32, 4 starbases.

CHANGE SINCE TURN 70
-----------------------------
P6: planets +16, population +51,902, factories +0, ships +112, fleet mass +0, tech total +6.
P5: planets +0, population +16,701, factories +1149, ships +14, fleet mass +0, tech total +4.
P7: planets +0, population +3,517, factories +403, ships +3, fleet mass +0, tech total +2.
P2: planets +3, population +6,604, factories +501, ships +1, fleet mass +0, tech total +1.
P3: planets +0, population +5,494, factories +325, ships +2, fleet mass +0, tech total +4.
P1: planets +2, population +2,029, factories +325, ships +3, fleet mass +0, tech total +1.
P4: planets +0, population +1,609, factories +313, ships +1, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P3 captured planet #106 from P1.
- P3 captured planet #346 from P4.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 137 planets.
- Population: P6 with 191,381.
- Industry: P5 with 5121 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 80.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
