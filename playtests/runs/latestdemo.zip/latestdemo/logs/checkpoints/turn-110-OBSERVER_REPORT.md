```
Stars! AI Observer Report - Turn 110 / Year 2510
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 13.3%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 22 planets, pop 126,750, 29960 factories, 406 ships / 0 fleet mass, tech total 99, 18 starbases.
2. P6 Berserker [Alternate Reality] - 184 planets, pop 1,251,558, 56 factories, 2685 ships / 0 fleet mass, tech total 133, 184 starbases.
3. P2 Kilingons [War Monger / Balanced] - 33 planets, pop 95,364, 9302 factories, 33 ships / 0 fleet mass, tech total 45, 19 starbases.
4. P7 Rush'n [Inner Strength] - 12 planets, pop 51,952, 7298 factories, 101 ships / 0 fleet mass, tech total 85, 7 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 24 planets, pop 57,063, 5540 factories, 72 ships / 0 fleet mass, tech total 88, 5 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 21 planets, pop 54,184, 5850 factories, 72 ships / 0 fleet mass, tech total 48, 8 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 6 planets, pop 13,122, 1344 factories, 42 ships / 0 fleet mass, tech total 42, 3 starbases.

CHANGE SINCE TURN 105
-----------------------------
P5: planets +0, population +2,583, factories +2612, ships -71, fleet mass +0, tech total +6.
P6: planets +0, population +224,467, factories +0, ships +454, fleet mass +0, tech total +8.
P2: planets +0, population +8,598, factories +1157, ships -2, fleet mass +0, tech total +2.
P7: planets +1, population +1,064, factories +794, ships +8, fleet mass +0, tech total +2.
P3: planets +1, population +2,002, factories +832, ships -6, fleet mass +0, tech total +2.
P1: planets +0, population +4,824, factories +677, ships +0, fleet mass +0, tech total +1.
P4: planets -2, population -9,202, factories -906, ships -23, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 184 planets.
- Population: P6 with 1,251,558.
- Industry: P5 with 29960 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 133.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P2 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
