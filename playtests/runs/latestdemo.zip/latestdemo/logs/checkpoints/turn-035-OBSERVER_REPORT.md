```
Stars! AI Observer Report - Turn 35 / Year 2435
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 96.8%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 66 planets, pop 14,125, 0 factories, 17 ships / 0 fleet mass, tech total 42, 66 starbases.
2. P5 Loraxoid [Super Stealth] - 21 planets, pop 8,951, 1122 factories, 44 ships / 0 fleet mass, tech total 30, 1 starbases.
3. P7 Rush'n [Inner Strength] - 6 planets, pop 10,434, 1098 factories, 2 ships / 0 fleet mass, tech total 34, 1 starbases.
4. P2 Kilingons [War Monger / Balanced] - 13 planets, pop 10,807, 562 factories, 32 ships / 0 fleet mass, tech total 27, 1 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 4 planets, pop 9,740, 424 factories, 38 ships / 0 fleet mass, tech total 30, 1 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 9 planets, pop 5,263, 282 factories, 29 ships / 0 fleet mass, tech total 23, 1 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 3,516, 178 factories, 22 ships / 0 fleet mass, tech total 18, 2 starbases.

CHANGE SINCE TURN 30
-----------------------------
P6: planets +12, population +3,755, factories +0, ships -1, fleet mass +0, tech total +4.
P5: planets +0, population +1,483, factories +385, ships +27, fleet mass +0, tech total +3.
P7: planets +1, population +2,204, factories +181, ships +0, fleet mass +0, tech total +8.
P2: planets +3, population +2,583, factories +170, ships +3, fleet mass +0, tech total +4.
P3: planets +1, population +2,072, factories +100, ships +5, fleet mass +0, tech total +11.
P1: planets +2, population +1,592, factories +112, ships +6, fleet mass +0, tech total +1.
P4: planets +0, population +896, factories +74, ships +0, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 66 planets.
- Population: P6 with 14,125.
- Industry: P5 with 1122 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 42.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
