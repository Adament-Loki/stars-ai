```
Stars! AI Observer Report - Turn 55 / Year 2455
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 79.4%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 90 planets, pop 58,875, 0 factories, 189 ships / 0 fleet mass, tech total 61, 90 starbases.
2. P5 Loraxoid [Super Stealth] - 20 planets, pop 19,605, 2533 factories, 123 ships / 0 fleet mass, tech total 51, 2 starbases.
3. P7 Rush'n [Inner Strength] - 8 planets, pop 24,965, 1657 factories, 29 ships / 0 fleet mass, tech total 51, 4 starbases.
4. P2 Kilingons [War Monger / Balanced] - 24 planets, pop 21,541, 1111 factories, 31 ships / 0 fleet mass, tech total 30, 2 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 14 planets, pop 17,154, 1227 factories, 49 ships / 0 fleet mass, tech total 48, 2 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 18 planets, pop 15,710, 1168 factories, 67 ships / 0 fleet mass, tech total 33, 2 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 10 planets, pop 9,612, 527 factories, 73 ships / 0 fleet mass, tech total 26, 3 starbases.

CHANGE SINCE TURN 50
-----------------------------
P6: planets +13, population +16,578, factories +0, ships +83, fleet mass +0, tech total +6.
P5: planets +0, population +4,732, factories +143, ships +8, fleet mass +0, tech total +5.
P7: planets +0, population +4,995, factories +269, ships +15, fleet mass +0, tech total +3.
P2: planets +3, population +4,444, factories +179, ships +1, fleet mass +0, tech total +1.
P3: planets +0, population +2,336, factories +225, ships +11, fleet mass +0, tech total +4.
P1: planets +1, population +2,707, factories +251, ships +10, fleet mass +0, tech total +1.
P4: planets +0, population +1,996, factories +2, ships +23, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 90 planets.
- Population: P6 with 58,875.
- Industry: P5 with 2533 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 61.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
