```
Stars! AI Observer Report - Turn 105 / Year 2505
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 14.7%.
Yes - fighting/conquest has begun. 2 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 22 planets, pop 124,167, 27348 factories, 477 ships / 0 fleet mass, tech total 93, 20 starbases.
2. P6 Berserker [Alternate Reality] - 184 planets, pop 1,027,091, 56 factories, 2231 ships / 0 fleet mass, tech total 125, 184 starbases.
3. P2 Kilingons [War Monger / Balanced] - 33 planets, pop 86,766, 8145 factories, 35 ships / 0 fleet mass, tech total 43, 17 starbases.
4. P7 Rush'n [Inner Strength] - 11 planets, pop 50,888, 6504 factories, 93 ships / 0 fleet mass, tech total 83, 7 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 23 planets, pop 55,061, 4708 factories, 78 ships / 0 fleet mass, tech total 86, 5 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 21 planets, pop 49,360, 5173 factories, 72 ships / 0 fleet mass, tech total 47, 7 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 8 planets, pop 22,324, 2250 factories, 65 ships / 0 fleet mass, tech total 42, 5 starbases.

CHANGE SINCE TURN 100
-----------------------------
P5: planets +0, population +5,585, factories +3691, ships +54, fleet mass +0, tech total +7.
P6: planets +0, population +193,637, factories +0, ships +381, fleet mass +0, tech total +8.
P2: planets +0, population +8,049, factories +1152, ships -3, fleet mass +0, tech total +1.
P7: planets +0, population -1,558, factories -371, ships +4, fleet mass +0, tech total +2.
P3: planets +1, population +52, factories +161, ships +12, fleet mass +0, tech total +5.
P1: planets +0, population +4,390, factories +784, ships -6, fleet mass +0, tech total +1.
P4: planets -2, population -130, factories -192, ships -3, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P3 captured planet #288 from P4.
- P3 captured planet #136 from P7.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 184 planets.
- Population: P6 with 1,027,091.
- Industry: P5 with 27348 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 125.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P2 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
