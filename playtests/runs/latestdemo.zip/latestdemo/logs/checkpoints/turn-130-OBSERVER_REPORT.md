```
Stars! AI Observer Report - Turn 130 / Year 2530
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 13.7%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 24 planets, pop 133,567, 31846 factories, 393 ships / 0 fleet mass, tech total 117, 20 starbases.
2. P6 Berserker [Alternate Reality] - 183 planets, pop 2,677,675, 56 factories, 3014 ships / 0 fleet mass, tech total 156, 183 starbases.
3. P2 Kilingons [War Monger / Balanced] - 29 planets, pop 99,701, 10847 factories, 28 ships / 0 fleet mass, tech total 69, 18 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 22 planets, pop 72,302, 8842 factories, 70 ships / 0 fleet mass, tech total 106, 13 starbases.
5. P1 Humanoid [Jack of All Trades / Balanced] - 18 planets, pop 71,724, 8820 factories, 56 ships / 0 fleet mass, tech total 72, 7 starbases.
6. P7 Rush'n [Inner Strength] - 11 planets, pop 56,806, 7864 factories, 112 ships / 0 fleet mass, tech total 95, 8 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 178, 0 factories, 11 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 125
-----------------------------
P5: planets -2, population -1,504, factories -2078, ships +19, fleet mass +0, tech total +5.
P6: planets +0, population +362,996, factories +0, ships +80, fleet mass +0, tech total +0.
P2: planets -1, population -5,601, factories +338, ships -7, fleet mass +0, tech total +7.
P3: planets -2, population +4,281, factories +1024, ships +4, fleet mass +0, tech total +3.
P1: planets -1, population +4,324, factories +822, ships -3, fleet mass +0, tech total +3.
P7: planets +0, population +1,018, factories +111, ships -1, fleet mass +0, tech total +4.
P4: planets +0, population +23, factories +0, ships -3, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 183 planets.
- Population: P6 with 2,677,675.
- Industry: P5 with 31846 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 156.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
