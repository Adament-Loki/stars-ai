```
Stars! AI Observer Report - Turn 70 / Year 2470
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 77.6%.
Yes - fighting/conquest has begun. 3 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 121 planets, pop 139,479, 0 factories, 451 ships / 0 fleet mass, tech total 74, 121 starbases.
2. P5 Loraxoid [Super Stealth] - 23 planets, pop 51,329, 3972 factories, 182 ships / 0 fleet mass, tech total 61, 7 starbases.
3. P7 Rush'n [Inner Strength] - 9 planets, pop 35,670, 4507 factories, 50 ships / 0 fleet mass, tech total 63, 6 starbases.
4. P2 Kilingons [War Monger / Balanced] - 30 planets, pop 31,992, 1957 factories, 30 ships / 0 fleet mass, tech total 33, 6 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 20 planets, pop 24,247, 2007 factories, 50 ships / 0 fleet mass, tech total 57, 3 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 23 planets, pop 25,753, 1917 factories, 88 ships / 0 fleet mass, tech total 37, 3 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 11 planets, pop 15,930, 1149 factories, 60 ships / 0 fleet mass, tech total 31, 2 starbases.

CHANGE SINCE TURN 65
-----------------------------
P6: planets +6, population +37,502, factories +0, ships +65, fleet mass +0, tech total +5.
P5: planets +1, population +13,547, factories +844, ships +41, fleet mass +0, tech total +4.
P7: planets +0, population +2,807, factories +492, ships +8, fleet mass +0, tech total +7.
P2: planets +2, population +6,559, factories +303, ships +0, fleet mass +0, tech total +1.
P3: planets +2, population +2,849, factories +328, ships +2, fleet mass +0, tech total +2.
P1: planets -2, population +2,687, factories +269, ships +2, fleet mass +0, tech total +2.
P4: planets -2, population +1,935, factories +275, ships -7, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P2 captured planet #119 from P1.
- P3 captured planet #118 from P1.
- P2 captured planet #63 from P1.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 121 planets.
- Population: P6 with 139,479.
- Industry: P7 with 4507 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 74.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
