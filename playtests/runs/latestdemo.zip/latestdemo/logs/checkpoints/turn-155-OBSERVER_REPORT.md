```
Stars! AI Observer Report - Turn 155 / Year 2555
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 13.6%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 29 planets, pop 106,440, 31016 factories, 471 ships / 0 fleet mass, tech total 131, 19 starbases.
2. P6 Berserker [Alternate Reality] - 177 planets, pop 3,781,594, 56 factories, 3173 ships / 0 fleet mass, tech total 156, 177 starbases.
3. P1 Humanoid [Jack of All Trades / Balanced] - 18 planets, pop 93,968, 13982 factories, 64 ships / 0 fleet mass, tech total 78, 11 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 15 planets, pop 52,655, 8710 factories, 81 ships / 0 fleet mass, tech total 111, 11 starbases.
5. P7 Rush'n [Inner Strength] - 9 planets, pop 42,494, 6452 factories, 86 ships / 0 fleet mass, tech total 105, 5 starbases.
6. P2 Kilingons [War Monger / Balanced] - 13 planets, pop 63,924, 6298 factories, 17 ships / 0 fleet mass, tech total 73, 9 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 2 planets, pop 325, 11 factories, 7 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 150
-----------------------------
P5: planets +7, population -377, factories +3260, ships +25, fleet mass +0, tech total +2.
P6: planets +0, population +191,676, factories +0, ships -70, fleet mass +0, tech total +0.
P1: planets +0, population +3,537, factories +935, ships +2, fleet mass +0, tech total +0.
P3: planets -1, population +2,248, factories +72, ships -5, fleet mass +0, tech total +2.
P7: planets -1, population -7,432, factories -611, ships -12, fleet mass +0, tech total +1.
P2: planets -8, population -24,134, factories -3060, ships +0, fleet mass +0, tech total +0.
P4: planets +0, population +50, factories +8, ships +0, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 177 planets.
- Population: P6 with 3,781,594.
- Industry: P5 with 31016 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 156.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
