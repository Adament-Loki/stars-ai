```
Stars! AI Observer Report - Turn 65 / Year 2465
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 97.8%.
Yes - fighting/conquest has begun. 1 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 115 planets, pop 101,977, 0 factories, 386 ships / 0 fleet mass, tech total 69, 115 starbases.
2. P5 Loraxoid [Super Stealth] - 22 planets, pop 37,782, 3128 factories, 141 ships / 0 fleet mass, tech total 57, 7 starbases.
3. P7 Rush'n [Inner Strength] - 9 planets, pop 32,863, 4015 factories, 42 ships / 0 fleet mass, tech total 56, 5 starbases.
4. P2 Kilingons [War Monger / Balanced] - 28 planets, pop 25,433, 1654 factories, 30 ships / 0 fleet mass, tech total 32, 5 starbases.
5. P1 Humanoid [Jack of All Trades / Balanced] - 25 planets, pop 23,066, 1648 factories, 86 ships / 0 fleet mass, tech total 35, 3 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 18 planets, pop 21,398, 1679 factories, 48 ships / 0 fleet mass, tech total 55, 3 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 13 planets, pop 13,995, 874 factories, 67 ships / 0 fleet mass, tech total 30, 2 starbases.

CHANGE SINCE TURN 60
-----------------------------
P6: planets +12, population +24,610, factories +0, ships +93, fleet mass +0, tech total +3.
P5: planets -2, population +12,538, factories +367, ships +2, fleet mass +0, tech total +3.
P7: planets +1, population +3,672, factories +1301, ships +8, fleet mass +0, tech total +1.
P2: planets +2, population +3,134, factories +239, ships +0, fleet mass +0, tech total +1.
P1: planets +3, population +3,685, factories +225, ships +1, fleet mass +0, tech total +1.
P3: planets +2, population +1,793, factories +281, ships +0, fleet mass +0, tech total +5.
P4: planets +1, population +2,609, factories +239, ships -1, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- P3 captured planet #149 from P1.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 115 planets.
- Population: P6 with 101,977.
- Industry: P7 with 4015 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 69.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
