```
Stars! AI Observer Report - Turn 40 / Year 2440
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 74.6%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 70 planets, pop 20,317, 0 factories, 25 ships / 0 fleet mass, tech total 45, 70 starbases.
2. P5 Loraxoid [Super Stealth] - 21 planets, pop 10,418, 1612 factories, 61 ships / 0 fleet mass, tech total 36, 1 starbases.
3. P7 Rush'n [Inner Strength] - 7 planets, pop 12,703, 1195 factories, 6 ships / 0 fleet mass, tech total 39, 1 starbases.
4. P2 Kilingons [War Monger / Balanced] - 15 planets, pop 13,046, 793 factories, 31 ships / 0 fleet mass, tech total 28, 1 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 6 planets, pop 11,585, 572 factories, 40 ships / 0 fleet mass, tech total 35, 1 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 10 planets, pop 7,652, 490 factories, 43 ships / 0 fleet mass, tech total 25, 1 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 6 planets, pop 4,745, 306 factories, 28 ships / 0 fleet mass, tech total 21, 2 starbases.

CHANGE SINCE TURN 35
-----------------------------
P6: planets +4, population +6,192, factories +0, ships +8, fleet mass +0, tech total +3.
P5: planets +0, population +1,467, factories +490, ships +17, fleet mass +0, tech total +6.
P7: planets +1, population +2,269, factories +97, ships +4, fleet mass +0, tech total +5.
P2: planets +2, population +2,239, factories +231, ships -1, fleet mass +0, tech total +1.
P3: planets +2, population +1,845, factories +148, ships +2, fleet mass +0, tech total +5.
P1: planets +1, population +2,389, factories +208, ships +14, fleet mass +0, tech total +2.
P4: planets +3, population +1,229, factories +128, ships +6, fleet mass +0, tech total +3.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 70 planets.
- Population: P6 with 20,317.
- Industry: P5 with 1612 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 45.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
