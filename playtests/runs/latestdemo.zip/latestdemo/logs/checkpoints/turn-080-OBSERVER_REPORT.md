```
Stars! AI Observer Report - Turn 80 / Year 2480
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 43.4%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 145 planets, pop 280,532, 0 factories, 847 ships / 0 fleet mass, tech total 87, 145 starbases.
2. P5 Loraxoid [Super Stealth] - 23 planets, pop 86,021, 8239 factories, 202 ships / 0 fleet mass, tech total 67, 14 starbases.
3. P7 Rush'n [Inner Strength] - 12 planets, pop 42,446, 5437 factories, 55 ships / 0 fleet mass, tech total 69, 6 starbases.
4. P2 Kilingons [War Monger / Balanced] - 34 planets, pop 45,288, 2995 factories, 32 ships / 0 fleet mass, tech total 36, 6 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 18 planets, pop 34,174, 2693 factories, 52 ships / 0 fleet mass, tech total 65, 4 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 26 planets, pop 31,156, 2581 factories, 95 ships / 0 fleet mass, tech total 39, 4 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 11 planets, pop 19,786, 1715 factories, 71 ships / 0 fleet mass, tech total 34, 5 starbases.

CHANGE SINCE TURN 75
-----------------------------
P6: planets +8, population +89,151, factories +0, ships +284, fleet mass +0, tech total +7.
P5: planets +0, population +17,991, factories +3118, ships +6, fleet mass +0, tech total +2.
P7: planets +3, population +3,259, factories +527, ships +2, fleet mass +0, tech total +4.
P2: planets +1, population +6,692, factories +537, ships +1, fleet mass +0, tech total +2.
P3: planets -2, population +4,433, factories +361, ships +0, fleet mass +0, tech total +4.
P1: planets +1, population +3,374, factories +339, ships +4, fleet mass +0, tech total +1.
P4: planets +0, population +2,247, factories +253, ships +10, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 145 planets.
- Population: P6 with 280,532.
- Industry: P5 with 8239 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 87.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
