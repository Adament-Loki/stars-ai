```
Stars! AI Observer Report - Turn 30 / Year 2430
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 99.9%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 54 planets, pop 10,370, 0 factories, 18 ships / 0 fleet mass, tech total 38, 54 starbases.
2. P5 Loraxoid [Super Stealth] - 21 planets, pop 7,468, 737 factories, 17 ships / 0 fleet mass, tech total 27, 1 starbases.
3. P7 Rush'n [Inner Strength] - 5 planets, pop 8,230, 917 factories, 2 ships / 0 fleet mass, tech total 26, 1 starbases.
4. P2 Kilingons [War Monger / Balanced] - 10 planets, pop 8,224, 392 factories, 29 ships / 0 fleet mass, tech total 23, 1 starbases.
5. P1 Humanoid [Jack of All Trades / Balanced] - 7 planets, pop 3,671, 170 factories, 23 ships / 0 fleet mass, tech total 22, 1 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 3 planets, pop 7,668, 324 factories, 33 ships / 0 fleet mass, tech total 19, 1 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 2,620, 104 factories, 22 ships / 0 fleet mass, tech total 16, 2 starbases.

CHANGE SINCE TURN 25
-----------------------------
P6: planets +11, population +2,647, factories +0, ships +3, fleet mass +0, tech total +7.
P5: planets +3, population +1,801, factories +382, ships +2, fleet mass +0, tech total +2.
P7: planets +1, population +2,298, factories +248, ships +0, fleet mass +0, tech total +7.
P2: planets +5, population +2,705, factories +125, ships -2, fleet mass +0, tech total +3.
P1: planets +3, population +1,295, factories +75, ships -2, fleet mass +0, tech total +1.
P3: planets +1, population +1,819, factories +125, ships +8, fleet mass +0, tech total +4.
P4: planets +0, population +705, factories +36, ships +0, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 54 planets.
- Population: P6 with 10,370.
- Industry: P7 with 917 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 38.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
