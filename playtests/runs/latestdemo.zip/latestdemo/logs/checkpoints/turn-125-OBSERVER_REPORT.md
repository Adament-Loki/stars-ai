```
Stars! AI Observer Report - Turn 125 / Year 2525
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 20.9%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 26 planets, pop 135,071, 33924 factories, 374 ships / 0 fleet mass, tech total 112, 17 starbases.
2. P6 Berserker [Alternate Reality] - 183 planets, pop 2,314,679, 56 factories, 2934 ships / 0 fleet mass, tech total 156, 183 starbases.
3. P2 Kilingons [War Monger / Balanced] - 30 planets, pop 105,302, 10509 factories, 35 ships / 0 fleet mass, tech total 62, 20 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 24 planets, pop 68,021, 7818 factories, 66 ships / 0 fleet mass, tech total 103, 13 starbases.
5. P7 Rush'n [Inner Strength] - 11 planets, pop 55,788, 7753 factories, 113 ships / 0 fleet mass, tech total 91, 7 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 19 planets, pop 67,400, 7998 factories, 59 ships / 0 fleet mass, tech total 69, 9 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 155, 0 factories, 14 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 120
-----------------------------
P5: planets +0, population -942, factories +1746, ships -40, fleet mass +0, tech total +4.
P6: planets +0, population +359,966, factories +0, ships +30, fleet mass +0, tech total +7.
P2: planets -1, population -1,194, factories +81, ships +0, fleet mass +0, tech total +3.
P3: planets +0, population +5,750, factories +1108, ships -4, fleet mass +0, tech total +4.
P7: planets +0, population +882, factories +123, ships +5, fleet mass +0, tech total +2.
P1: planets +0, population +4,706, factories +858, ships -10, fleet mass +0, tech total +3.
P4: planets -1, population -6,099, factories -570, ships -4, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 183 planets.
- Population: P6 with 2,314,679.
- Industry: P5 with 33924 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 156.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
