```
Stars! AI Observer Report - Turn 165 / Year 2565
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 21.1%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 30 planets, pop 108,131, 33576 factories, 437 ships / 0 fleet mass, tech total 136, 18 starbases.
2. P6 Berserker [Alternate Reality] - 177 planets, pop 4,118,811, 56 factories, 3184 ships / 0 fleet mass, tech total 156, 177 starbases.
3. P1 Humanoid [Jack of All Trades / Balanced] - 19 planets, pop 101,431, 16739 factories, 48 ships / 0 fleet mass, tech total 79, 10 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 16 planets, pop 68,060, 12787 factories, 58 ships / 0 fleet mass, tech total 115, 12 starbases.
5. P2 Kilingons [War Monger / Balanced] - 10 planets, pop 60,208, 5981 factories, 19 ships / 0 fleet mass, tech total 73, 8 starbases.
6. P7 Rush'n [Inner Strength] - 6 planets, pop 21,809, 3517 factories, 47 ships / 0 fleet mass, tech total 106, 3 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 2 planets, pop 457, 41 factories, 1 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 160
-----------------------------
P5: planets +6, population -3,764, factories +3236, ships -30, fleet mass +0, tech total +2.
P6: planets +0, population +155,516, factories +0, ships +392, fleet mass +0, tech total +0.
P1: planets +0, population +3,146, factories +1688, ships -10, fleet mass +0, tech total +1.
P3: planets -2, population +6,300, factories +2836, ships -13, fleet mass +0, tech total +4.
P2: planets -2, population +3,099, factories +218, ships +1, fleet mass +0, tech total +0.
P7: planets -2, population -13,181, factories -1688, ships -32, fleet mass +0, tech total +1.
P4: planets +0, population +72, factories +15, ships -6, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- P2 suffered a major net fleet loss during Turn 162 / Year 2562 (ships 20->16; fleets 20->16; net loss 4 ships). Observed fleet change: fleet ID 4 disappeared (1 ships; last seen at (1677, 1174)); fleet ID 5 disappeared (1 ships; last seen at (1566, 1724)); fleet ID 7 disappeared (1 ships; last seen at (1616, 1217)); fleet ID 44 disappeared (1 ships; last seen at (1516, 1857)). Cause is not decoded.
- P4 suffered a major net fleet loss during Turn 163 / Year 2563 (ships 6->1; fleets 3->1; net loss 5 ships). Observed fleet change: fleet ID 1 disappeared (3 ships; last seen at (2089, 1703)); fleet ID 15 disappeared (2 ships; last seen at (2101, 1813)). Cause is not decoded.
- P7 suffered a major net fleet loss during Turn 164 / Year 2564 (ships 75->54; fleets 29->27; net loss 21 ships). Observed fleet change: fleet ID 24 disappeared (12 ships; last seen at (1440, 1797)); fleet ID 4 disappeared (9 ships; last seen at (1440, 1797)). Cause is not decoded.
- P1 suffered a major net fleet loss during Turn 165 / Year 2565 (ships 59->48; fleets 59->48; net loss 11 ships). Observed fleet change: fleet ID 8 disappeared (1 ships; last seen at (1281, 2121)); fleet ID 10 disappeared (1 ships; last seen at (1271, 2104)); fleet ID 16 disappeared (1 ships; last seen at (1281, 2121)); fleet ID 17 disappeared (1 ships; last seen at (1281, 2121)); fleet ID 19 disappeared (1 ships; last seen at (1281, 2121)); fleet ID 24 disappeared (1 ships; last seen at (1310, 2129)); fleet ID 28 disappeared (1 ships; last seen at (1294, 2112)); fleet ID 29 disappeared (1 ships; last seen at (1366, 1562)); fleet ID 30 disappeared (1 ships; last seen at (1932, 2059)); fleet ID 33 disappeared (1 ships; last seen at (1375, 2096)); fleet ID 38 disappeared (1 ships; last seen at (1932, 2059)); fleet ID 41 disappeared (1 ships; last seen at (1932, 2059)); fleet ID 44 disappeared (1 ships; last seen at (1226, 2086)); fleet ID 46 disappeared (1 ships; last seen at (1382, 2093)); fleet ID 47 disappeared (1 ships; last seen at (1360, 2014)); fleet ID 48 disappeared (1 ships; last seen at (1932, 2059)); fleet ID 51 disappeared (1 ships; last seen at (1932, 2059)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 177 planets.
- Population: P6 with 4,118,811.
- Industry: P5 with 33576 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 156.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
