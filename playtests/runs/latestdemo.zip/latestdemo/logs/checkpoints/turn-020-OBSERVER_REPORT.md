```
Stars! AI Observer Report - Turn 20 / Year 2420
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 95.0%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 31 planets, pop 6,032, 0 factories, 9 ships / 0 fleet mass, tech total 23, 31 starbases.
2. P5 Loraxoid [Super Stealth] - 14 planets, pop 3,550, 155 factories, 12 ships / 0 fleet mass, tech total 24, 1 starbases.
3. P7 Rush'n [Inner Strength] - 3 planets, pop 3,406, 370 factories, 2 ships / 0 fleet mass, tech total 18, 1 starbases.
4. P2 Kilingons [War Monger / Balanced] - 2 planets, pop 3,852, 148 factories, 22 ships / 0 fleet mass, tech total 17, 1 starbases.
5. P1 Humanoid [Jack of All Trades / Balanced] - 2 planets, pop 1,578, 63 factories, 13 ships / 0 fleet mass, tech total 20, 1 starbases.
6. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 1,361, 32 factories, 22 ships / 0 fleet mass, tech total 15, 2 starbases.
7. P3 Romulans [Super Stealth / Balanced] - 2 planets, pop 3,792, 114 factories, 11 ships / 0 fleet mass, tech total 11, 1 starbases.

CHANGE SINCE TURN 15
-----------------------------
P6: planets +12, population +2,577, factories +0, ships +3, fleet mass +0, tech total +7.
P5: planets +4, population +1,639, factories +75, ships -1, fleet mass +0, tech total +3.
P7: planets +2, population +1,631, factories +186, ships +0, fleet mass +0, tech total +0.
P2: planets +1, population +1,821, factories +79, ships +14, fleet mass +0, tech total +1.
P1: planets +0, population +656, factories +30, ships +4, fleet mass +0, tech total +1.
P4: planets +0, population +437, factories +10, ships +5, fleet mass +0, tech total +1.
P3: planets +0, population +1,786, factories +67, ships +7, fleet mass +0, tech total +3.

WAR & CONTACT
-------------
- P5 suffered a major net fleet loss during Turn 19 / Year 2419 (ships 12->9; fleets 12->9; net loss 3 ships). Observed fleet change: fleet ID 10 disappeared (1 ships; last seen at (1331, 1212)); fleet ID 11 disappeared (1 ships; last seen at (1624, 1053)); fleet ID 13 disappeared (1 ships; last seen at (1596, 1320)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 31 planets.
- Population: P6 with 6,032.
- Industry: P7 with 370 factories.
- Fleet by mass: P6 with 0.
- Technology: P5 with tech total 24.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P3 Romulans.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
