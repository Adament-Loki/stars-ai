```
Stars! AI Observer Report — Turn 25 / Year 2425
==================================================================

EXECUTIVE SUMMARY
-----------------
P3 Hooveron has a clear lead. Observer score gap over second place: 59.6%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P3 Hooveron [Packet Physics] — 29 planets, pop 13,723, 391 factories, 22 ships / 0 fleet mass, techΣ 22, 2 starbases.
2. P1 SuperRabits [Interstellar Traveler / Balanced] — 15 planets, pop 6,626, 183 factories, 24 ships / 0 fleet mass, techΣ 23, 2 starbases.
3. P2 Valadiac [Interstellar Traveler / Expansionist] — 13 planets, pop 5,943, 200 factories, 27 ships / 0 fleet mass, techΣ 23, 2 starbases.

CHANGE SINCE TURN 10
-----------------------------
P3: planets +18, population +10,310, factories +337, ships +14, fleet mass +0, techΣ +9.
P1: planets +8, population +4,449, factories +143, ships +8, fleet mass +0, techΣ +9.
P2: planets +9, population +3,951, factories +148, ships +12, fleet mass +0, techΣ +9.

WAR & CONTACT
-------------
- P1 suffered a major net fleet loss (3 ships, 0 mass).
- P1 suffered a major net fleet loss (5 ships, 0 mass).

WHO IS STRONGEST?
-----------------
- Territory: P3 with 29 planets.
- Population: P3 with 13,723.
- Industry: P3 with 391 factories.
- Fleet by mass: P3 with 0.
- Technology: P1 with techΣ 23.

MOMENTUM / RISK
---------------
- Current leader: P3 Hooveron.
- Current last place: P2 Valadiac.
- P2 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
