```
Stars! AI Observer Report - Turn 25 / Year 2425
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 107.3%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 43 planets, pop 7,723, 0 factories, 15 ships / 0 fleet mass, tech total 31, 43 starbases.
2. P5 Loraxoid [Super Stealth] - 18 planets, pop 5,667, 355 factories, 15 ships / 0 fleet mass, tech total 25, 1 starbases.
3. P7 Rush'n [Inner Strength] - 4 planets, pop 5,932, 669 factories, 2 ships / 0 fleet mass, tech total 19, 1 starbases.
4. P2 Kilingons [War Monger / Balanced] - 5 planets, pop 5,519, 267 factories, 31 ships / 0 fleet mass, tech total 20, 1 starbases.
5. P1 Humanoid [Jack of All Trades / Balanced] - 4 planets, pop 2,376, 95 factories, 25 ships / 0 fleet mass, tech total 21, 1 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 2 planets, pop 5,849, 199 factories, 25 ships / 0 fleet mass, tech total 15, 1 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 1,915, 68 factories, 22 ships / 0 fleet mass, tech total 15, 2 starbases.

CHANGE SINCE TURN 20
-----------------------------
P6: planets +12, population +1,691, factories +0, ships +6, fleet mass +0, tech total +8.
P5: planets +4, population +2,117, factories +200, ships +3, fleet mass +0, tech total +1.
P7: planets +1, population +2,526, factories +299, ships +0, fleet mass +0, tech total +1.
P2: planets +3, population +1,667, factories +119, ships +9, fleet mass +0, tech total +3.
P1: planets +2, population +798, factories +32, ships +12, fleet mass +0, tech total +1.
P3: planets +0, population +2,057, factories +85, ships +14, fleet mass +0, tech total +4.
P4: planets +0, population +554, factories +36, ships +0, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- P5 suffered a major net fleet loss during Turn 24 / Year 2424 (ships 14->11; fleets 12->9; net loss 3 ships). Observed fleet change: fleet ID 10 disappeared (1 ships; last seen at (1658, 1122)); fleet ID 11 disappeared (1 ships; last seen at (1309, 1177)); fleet ID 12 disappeared (1 ships; last seen at (1678, 1156)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 43 planets.
- Population: P6 with 7,723.
- Industry: P7 with 669 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 31.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P5 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
