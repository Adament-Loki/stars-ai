```
Stars! AI Observer Report - Turn 195 / Year 2595
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 29.3%.
Yes - fighting/conquest has begun. 1 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 27 planets, pop 106,952, 34579 factories, 503 ships / 0 fleet mass, tech total 155, 22 starbases.
2. P6 Berserker [Alternate Reality] - 177 planets, pop 4,764,321, 56 factories, 2984 ships / 0 fleet mass, tech total 156, 177 starbases.
3. P1 Humanoid [Jack of All Trades / Balanced] - 13 planets, pop 75,071, 13438 factories, 53 ships / 0 fleet mass, tech total 79, 7 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 6 planets, pop 23,814, 8288 factories, 49 ships / 0 fleet mass, tech total 120, 3 starbases.
5. P7 Rush'n [Inner Strength] - 2 planets, pop 6,217, 856 factories, 9 ships / 0 fleet mass, tech total 113, 0 starbases.
6. P2 Kilingons [War Monger / Balanced] - 1 planets, pop 8,607, 798 factories, 2 ships / 0 fleet mass, tech total 73, 1 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 0 planets, pop 0, 0 factories, 0 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 190
-----------------------------
P5: planets -1, population +3,322, factories -504, ships -4, fleet mass +0, tech total +2.
P6: planets +0, population +69,091, factories +0, ships +344, fleet mass +0, tech total +0.
P1: planets -2, population -4,648, factories -1899, ships -4, fleet mass +0, tech total +0.
P3: planets -1, population +2,439, factories +1155, ships +0, fleet mass +0, tech total +2.
P7: planets +0, population +266, factories +30, ships -32, fleet mass +0, tech total +0.
P2: planets +0, population +145, factories +0, ships -3, fleet mass +0, tech total +0.
P4: planets +0, population +0, factories +0, ships +0, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- P1 captured planet #118 from P3.
- P7 suffered a major net fleet loss during Turn 195 / Year 2595 (ships 41->9; fleets 11->9; net loss 32 ships). Observed fleet change: fleet ID 1 disappeared (20 ships; last seen at (1087, 1679)); fleet ID 2 disappeared (12 ships; last seen at (1087, 1679)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 177 planets.
- Population: P6 with 4,764,321.
- Industry: P5 with 34579 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 156.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P1 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P4 has no planets and is effectively eliminated.

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
