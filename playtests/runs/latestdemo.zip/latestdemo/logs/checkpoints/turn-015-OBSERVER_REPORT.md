```
Stars! AI Observer Report - Turn 15 / Year 2415
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 63.0%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 19 planets, pop 3,455, 0 factories, 6 ships / 0 fleet mass, tech total 16, 19 starbases.
2. P5 Loraxoid [Super Stealth] - 10 planets, pop 1,911, 80 factories, 13 ships / 0 fleet mass, tech total 21, 1 starbases.
3. P7 Rush'n [Inner Strength] - 1 planets, pop 1,775, 184 factories, 2 ships / 0 fleet mass, tech total 18, 1 starbases.
4. P4 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 924, 22 factories, 17 ships / 0 fleet mass, tech total 14, 2 starbases.
5. P1 Humanoid [Jack of All Trades / Balanced] - 2 planets, pop 922, 33 factories, 9 ships / 0 fleet mass, tech total 19, 1 starbases.
6. P2 Kilingons [War Monger / Balanced] - 1 planets, pop 2,031, 69 factories, 8 ships / 0 fleet mass, tech total 16, 1 starbases.
7. P3 Romulans [Super Stealth / Balanced] - 2 planets, pop 2,006, 47 factories, 4 ships / 0 fleet mass, tech total 8, 1 starbases.

CHANGE SINCE TURN 10
-----------------------------
P6: planets +12, population +1,840, factories +0, ships +3, fleet mass +0, tech total +9.
P5: planets +6, population +941, factories +56, ships +2, fleet mass +0, tech total +0.
P7: planets +0, population +930, factories +98, ships +1, fleet mass +0, tech total +0.
P4: planets +0, population +304, factories +1, ships +9, fleet mass +0, tech total +0.
P1: planets +0, population +288, factories +21, ships +4, fleet mass +0, tech total +0.
P2: planets +0, population +1,021, factories +45, ships +6, fleet mass +0, tech total +2.
P3: planets +1, population +996, factories +37, ships +1, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- P5 suffered a major net fleet loss during Turn 14 / Year 2414 (ships 13->10; fleets 13->10; net loss 3 ships). Observed fleet change: fleet ID 9 disappeared (1 ships; last seen at (1567, 1170)); fleet ID 10 disappeared (1 ships; last seen at (1523, 1235)); fleet ID 11 disappeared (1 ships; last seen at (1434, 1101)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 19 planets.
- Population: P6 with 3,455.
- Industry: P7 with 184 factories.
- Fleet by mass: P6 with 0.
- Technology: P5 with tech total 21.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P3 Romulans.
- P7 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
