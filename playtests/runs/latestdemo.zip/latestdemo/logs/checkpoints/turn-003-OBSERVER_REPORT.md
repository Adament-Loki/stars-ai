```
Stars! AI Observer Report - Turn 3 / Year 2403
==================================================================

EXECUTIVE SUMMARY
-----------------
The game remains competitive; P5 Loraxoid currently has a narrow lead. Observer score gap over second place: 6.3%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 1 planets, pop 380, 10 factories, 5 ships / 0 fleet mass, tech total 21, 1 starbases.
2. P1 Humanoid [Jack of All Trades / Balanced] - 1 planets, pop 332, 12 factories, 6 ships / 0 fleet mass, tech total 19, 1 starbases.
3. P4 SuperRabits [Interstellar Traveler / Balanced] - 2 planets, pop 371, 16 factories, 5 ships / 0 fleet mass, tech total 14, 2 starbases.
4. P7 Rush'n [Inner Strength] - 1 planets, pop 299, 19 factories, 1 ships / 0 fleet mass, tech total 18, 1 starbases.
5. P2 Kilingons [War Monger / Balanced] - 1 planets, pop 380, 12 factories, 2 ships / 0 fleet mass, tech total 14, 1 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 1 planets, pop 380, 10 factories, 3 ships / 0 fleet mass, tech total 6, 1 starbases.
7. P6 Berserker [Alternate Reality] - 1 planets, pop 475, 0 factories, 1 ships / 0 fleet mass, tech total 3, 1 starbases.

CHANGE SINCE TURN 0
-----------------------------
P5: planets +0, population +105, factories +0, ships +1, fleet mass +0, tech total +0.
P1: planets +0, population +82, factories +0, ships +0, fleet mass +0, tech total +0.
P4: planets +0, population +71, factories +2, ships +0, fleet mass +0, tech total +0.
P7: planets +0, population +107, factories +9, ships -1, fleet mass +0, tech total +0.
P2: planets +0, population +130, factories +0, ships +0, fleet mass +0, tech total +0.
P3: planets +0, population +130, factories +0, ships +0, fleet mass +0, tech total +0.
P6: planets +0, population +200, factories +0, ships -3, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P6 suffered a major net fleet loss during Turn 1 / Year 2401 (ships 4->1; fleets 4->1; net loss 3 ships). Observed fleet change: fleet ID 0 disappeared (1 ships; last seen at (1874, 1331)); fleet ID 1 disappeared (1 ships; last seen at (1874, 1331)); fleet ID 2 disappeared (1 ships; last seen at (1874, 1331)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P4 with 2 planets.
- Population: P6 with 475.
- Industry: P7 with 19 factories.
- Fleet by mass: P5 with 0.
- Technology: P5 with tech total 21.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P6 Berserker.
- P3 is materially behind the leader (<60% of leader observer score).
- P6 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
