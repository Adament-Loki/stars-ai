```
Stars! AI Observer Report - Turn 120 / Year 2520
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 17.2%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 26 planets, pop 136,013, 32178 factories, 414 ships / 0 fleet mass, tech total 108, 19 starbases.
2. P6 Berserker [Alternate Reality] - 183 planets, pop 1,954,713, 56 factories, 2904 ships / 0 fleet mass, tech total 149, 183 starbases.
3. P2 Kilingons [War Monger / Balanced] - 31 planets, pop 106,496, 10428 factories, 35 ships / 0 fleet mass, tech total 59, 20 starbases.
4. P3 Romulans [Super Stealth / Balanced] - 24 planets, pop 62,271, 6710 factories, 70 ships / 0 fleet mass, tech total 99, 9 starbases.
5. P7 Rush'n [Inner Strength] - 11 planets, pop 54,906, 7630 factories, 108 ships / 0 fleet mass, tech total 89, 7 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 19 planets, pop 62,694, 7140 factories, 69 ships / 0 fleet mass, tech total 66, 9 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 4 planets, pop 6,254, 570 factories, 18 ships / 0 fleet mass, tech total 48, 0 starbases.

CHANGE SINCE TURN 115
-----------------------------
P5: planets +1, population +5,307, factories +561, ships -6, fleet mass +0, tech total +4.
P6: planets -1, population +377,223, factories +0, ships +242, fleet mass +0, tech total +6.
P2: planets -1, population +859, factories +165, ships +2, fleet mass +0, tech total +13.
P3: planets -1, population -16, factories +464, ships +1, fleet mass +0, tech total +5.
P7: planets +0, population +1,360, factories +464, ships -2, fleet mass +0, tech total +3.
P1: planets +0, population +4,838, factories +762, ships +4, fleet mass +0, tech total +5.
P4: planets -1, population -5,547, factories -573, ships -9, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 183 planets.
- Population: P6 with 1,954,713.
- Industry: P5 with 32178 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 149.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
