```
Stars! AI Observer Report - Turn 50 / Year 2450
==================================================================

EXECUTIVE SUMMARY
-----------------
P6 Berserker has a clear lead. Observer score gap over second place: 59.2%.
Yes - fighting/conquest has begun. 1 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P6 Berserker [Alternate Reality] - 77 planets, pop 42,297, 0 factories, 106 ships / 0 fleet mass, tech total 55, 77 starbases.
2. P5 Loraxoid [Super Stealth] - 20 planets, pop 14,873, 2390 factories, 115 ships / 0 fleet mass, tech total 46, 1 starbases.
3. P7 Rush'n [Inner Strength] - 8 planets, pop 19,970, 1388 factories, 14 ships / 0 fleet mass, tech total 48, 2 starbases.
4. P2 Kilingons [War Monger / Balanced] - 21 planets, pop 17,097, 932 factories, 30 ships / 0 fleet mass, tech total 29, 2 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 14 planets, pop 14,818, 1002 factories, 38 ships / 0 fleet mass, tech total 44, 2 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 17 planets, pop 13,003, 917 factories, 57 ships / 0 fleet mass, tech total 32, 2 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 10 planets, pop 7,616, 525 factories, 50 ships / 0 fleet mass, tech total 25, 3 starbases.

CHANGE SINCE TURN 45
-----------------------------
P6: planets +1, population +14,295, factories +0, ships +65, fleet mass +0, tech total +5.
P5: planets +0, population +2,458, factories +351, ships +29, fleet mass +0, tech total +5.
P7: planets +1, population +4,364, factories +113, ships +4, fleet mass +0, tech total +4.
P2: planets +3, population +2,778, factories +31, ships +0, fleet mass +0, tech total +0.
P3: planets +1, population +2,157, factories +225, ships +3, fleet mass +0, tech total +3.
P1: planets +4, population +3,427, factories +222, ships +5, fleet mass +0, tech total +3.
P4: planets +3, population +1,533, factories +91, ships +15, fleet mass +0, tech total +3.

WAR & CONTACT
-------------
- P2 captured planet #91 from P5.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 77 planets.
- Population: P6 with 42,297.
- Industry: P5 with 2390 factories.
- Fleet by mass: P6 with 0.
- Technology: P6 with tech total 55.

MOMENTUM / RISK
---------------
- Current leader: P6 Berserker.
- Current last place: P4 SuperRabits.
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
