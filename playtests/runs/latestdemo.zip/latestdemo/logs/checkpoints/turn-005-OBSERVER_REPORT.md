```
Stars! AI Observer Report - Turn 5 / Year 2405
==================================================================

EXECUTIVE SUMMARY
-----------------
P5 Loraxoid is leading. Observer score gap over second place: 18.1%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 2 planets, pop 527, 10 factories, 6 ships / 0 fleet mass, tech total 21, 1 starbases.
2. P1 Humanoid [Jack of All Trades / Balanced] - 1 planets, pop 374, 12 factories, 6 ships / 0 fleet mass, tech total 19, 1 starbases.
3. P4 SuperRabits [Interstellar Traveler / Balanced] - 2 planets, pop 403, 18 factories, 5 ships / 0 fleet mass, tech total 14, 2 starbases.
4. P7 Rush'n [Inner Strength] - 1 planets, pop 402, 19 factories, 1 ships / 0 fleet mass, tech total 18, 1 starbases.
5. P2 Kilingons [War Monger / Balanced] - 1 planets, pop 502, 13 factories, 2 ships / 0 fleet mass, tech total 14, 1 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 1 planets, pop 502, 10 factories, 3 ships / 0 fleet mass, tech total 6, 1 starbases.
7. P6 Berserker [Alternate Reality] - 1 planets, pop 684, 0 factories, 1 ships / 0 fleet mass, tech total 5, 1 starbases.

CHANGE SINCE TURN 3
-----------------------------
P5: planets +1, population +147, factories +0, ships +1, fleet mass +0, tech total +0.
P1: planets +0, population +42, factories +0, ships +0, fleet mass +0, tech total +0.
P4: planets +0, population +32, factories +2, ships +0, fleet mass +0, tech total +0.
P7: planets +0, population +103, factories +0, ships +0, fleet mass +0, tech total +0.
P2: planets +0, population +122, factories +1, ships +0, fleet mass +0, tech total +0.
P3: planets +0, population +122, factories +0, ships +0, fleet mass +0, tech total +0.
P6: planets +0, population +209, factories +0, ships +0, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P5 with 2 planets.
- Population: P6 with 684.
- Industry: P7 with 19 factories.
- Fleet by mass: P5 with 0.
- Technology: P5 with tech total 21.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P6 Berserker.
- P3 is materially behind the leader (<60% of leader observer score).
- P6 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
