```
Stars! AI Observer Report - Turn 90 / Year 2490
==================================================================

EXECUTIVE SUMMARY
-----------------
The game remains competitive; P5 Loraxoid currently has a narrow lead. Observer score gap over second place: 7.7%.
Yes - fighting/conquest has begun. 1 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 25 planets, pop 108,310, 17888 factories, 278 ships / 0 fleet mass, tech total 73, 22 starbases.
2. P6 Berserker [Alternate Reality] - 167 planets, pop 536,428, 0 factories, 1067 ships / 0 fleet mass, tech total 100, 167 starbases.
3. P7 Rush'n [Inner Strength] - 8 planets, pop 46,829, 6124 factories, 87 ships / 0 fleet mass, tech total 74, 7 starbases.
4. P2 Kilingons [War Monger / Balanced] - 34 planets, pop 62,154, 4558 factories, 36 ships / 0 fleet mass, tech total 38, 13 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 17 planets, pop 41,970, 3598 factories, 52 ships / 0 fleet mass, tech total 73, 6 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 25 planets, pop 37,357, 3205 factories, 90 ships / 0 fleet mass, tech total 43, 5 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 14 planets, pop 24,285, 2260 factories, 65 ships / 0 fleet mass, tech total 38, 6 starbases.

CHANGE SINCE TURN 85
-----------------------------
P5: planets +0, population +8,746, factories +5881, ships +28, fleet mass +0, tech total +4.
P6: planets +10, population +131,352, factories +0, ships +102, fleet mass +0, tech total +8.
P7: planets -2, population +1,666, factories +229, ships +6, fleet mass +0, tech total +4.
P2: planets +0, population +8,623, factories +894, ships +1, fleet mass +0, tech total +1.
P3: planets +1, population +4,610, factories +484, ships +0, fleet mass +0, tech total +4.
P1: planets -1, population +3,938, factories +377, ships -7, fleet mass +0, tech total +2.
P4: planets +2, population +2,290, factories +210, ships -12, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P3 captured planet #315 from P4.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 167 planets.
- Population: P6 with 536,428.
- Industry: P5 with 17888 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 100.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
