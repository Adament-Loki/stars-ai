```
Stars! AI Observer Report - Turn 95 / Year 2495
==================================================================

EXECUTIVE SUMMARY
-----------------
The game remains competitive; P5 Loraxoid currently has a narrow lead. Observer score gap over second place: 9.4%.
Yes - fighting/conquest has begun. 5 enemy planet capture(s) occurred in the reporting window.

CURRENT STANDINGS
-----------------
1. P5 Loraxoid [Super Stealth] - 23 planets, pop 111,654, 21253 factories, 392 ships / 0 fleet mass, tech total 78, 21 starbases.
2. P6 Berserker [Alternate Reality] - 176 planets, pop 684,449, 0 factories, 1510 ships / 0 fleet mass, tech total 107, 176 starbases.
3. P7 Rush'n [Inner Strength] - 10 planets, pop 49,538, 6467 factories, 90 ships / 0 fleet mass, tech total 77, 7 starbases.
4. P2 Kilingons [War Monger / Balanced] - 32 planets, pop 70,003, 5750 factories, 40 ships / 0 fleet mass, tech total 40, 14 starbases.
5. P3 Romulans [Super Stealth / Balanced] - 21 planets, pop 49,962, 4155 factories, 49 ships / 0 fleet mass, tech total 77, 6 starbases.
6. P1 Humanoid [Jack of All Trades / Balanced] - 23 planets, pop 41,150, 3760 factories, 85 ships / 0 fleet mass, tech total 45, 5 starbases.
7. P4 SuperRabits [Interstellar Traveler / Balanced] - 11 planets, pop 23,714, 2459 factories, 72 ships / 0 fleet mass, tech total 39, 5 starbases.

CHANGE SINCE TURN 90
-----------------------------
P5: planets -2, population +3,344, factories +3365, ships +114, fleet mass +0, tech total +5.
P6: planets +9, population +148,021, factories +0, ships +443, fleet mass +0, tech total +7.
P7: planets +2, population +2,709, factories +343, ships +3, fleet mass +0, tech total +3.
P2: planets -2, population +7,849, factories +1192, ships +4, fleet mass +0, tech total +2.
P3: planets +4, population +7,992, factories +557, ships -3, fleet mass +0, tech total +4.
P1: planets -2, population +3,793, factories +555, ships -5, fleet mass +0, tech total +2.
P4: planets -3, population -571, factories +199, ships +7, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P3 captured planet #94 from P1.
- P3 captured planet #349 from P4.
- P7 captured planet #136 from P3.
- P3 captured planet #319 from P4.
- P3 captured planet #89 from P1.

WHO IS STRONGEST?
-----------------
- Territory: P6 with 176 planets.
- Population: P6 with 684,449.
- Industry: P5 with 21253 factories.
- Fleet by mass: P5 with 0.
- Technology: P6 with tech total 107.

MOMENTUM / RISK
---------------
- Current leader: P5 Loraxoid.
- Current last place: P4 SuperRabits.
- P7 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
