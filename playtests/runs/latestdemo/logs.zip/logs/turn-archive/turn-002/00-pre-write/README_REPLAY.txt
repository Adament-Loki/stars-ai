STARS! AI immutable turn archive
Turn: turn-002
Phase: 00-pre-write

The game/ directory is a byte-for-byte snapshot of the native game files at this phase.
Do not overwrite the archive. Copy it to a separate replay workspace before experiments.
manifest.json contains SHA-256 hashes and source-stability checks for every captured file.
