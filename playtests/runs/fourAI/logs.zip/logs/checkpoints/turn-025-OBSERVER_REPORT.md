```
Stars! AI Observer Report — Turn 25 / Year 2425
==================================================================

EXECUTIVE SUMMARY
-----------------
The game remains competitive; P3 Ubert currently has a narrow lead. Observer score gap over second place: 7.0%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P3 Ubert [Packet Physics] — 13 planets, pop 3,844, 44 factories, 6 ships / 0 fleet mass, techΣ 15, 2 starbases.
2. P1 SuperRabits [Interstellar Traveler / Balanced] — 8 planets, pop 2,669, 60 factories, 7 ships / 0 fleet mass, techΣ 25, 2 starbases.
3. P2 Rush'n [Interstellar Traveler / Expansionist] — 7 planets, pop 2,505, 28 factories, 7 ships / 0 fleet mass, techΣ 24, 2 starbases.

CHANGE SINCE TURN 10
-----------------------------
P3: planets +7, population +3,216, factories +30, ships +5, fleet mass +0, techΣ +3.
P1: planets +6, population +1,999, factories +30, ships -4, fleet mass +0, techΣ +10.
P2: planets +5, population +1,865, factories +5, ships -4, fleet mass +0, techΣ +9.

WAR & CONTACT
-------------
- P2 suffered a major net fleet loss (4 ships, 0 mass).

WHO IS STRONGEST?
-----------------
- Territory: P3 with 13 planets.
- Population: P3 with 3,844.
- Industry: P1 with 60 factories.
- Fleet by mass: P3 with 0.
- Technology: P1 with techΣ 25.

MOMENTUM / RISK
---------------
- Current leader: P3 Ubert.
- Current last place: P2 Rush'n.

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
