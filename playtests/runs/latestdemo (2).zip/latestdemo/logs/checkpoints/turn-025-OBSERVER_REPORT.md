```
Stars! AI Observer Report - Turn 25 / Year 2425
==================================================================

EXECUTIVE SUMMARY
-----------------
P7 Felite has a clear lead. Observer score gap over second place: 69.2%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P7 Felite [Hyper Expansion] - 45 planets, pop 3,329, 218 factories, 19 ships / 0 fleet mass, tech total 24, 1 starbases.
2. P10 Tritizoid [Alternate Reality] - 19 planets, pop 4,772, 0 factories, 6 ships / 0 fleet mass, tech total 23, 19 starbases.
3. P9 Hawk [Packet Physics] - 13 planets, pop 3,831, 60 factories, 8 ships / 0 fleet mass, tech total 18, 2 starbases.
4. P4 Kilingons [War Monger / Balanced] - 4 planets, pop 5,776, 340 factories, 30 ships / 0 fleet mass, tech total 19, 1 starbases.
5. P8 Picardi [Inner Strength] - 3 planets, pop 4,915, 537 factories, 2 ships / 0 fleet mass, tech total 20, 1 starbases.
6. P2 S2 [Inner Strength / Balanced] - 7 planets, pop 5,853, 261 factories, 24 ships / 0 fleet mass, tech total 14, 1 starbases.
7. P1 SuperRabits [Interstellar Traveler / Balanced] - 10 planets, pop 2,364, 26 factories, 5 ships / 0 fleet mass, tech total 18, 2 starbases.
8. P5 Humanoid [Jack of All Trades / Balanced] - 6 planets, pop 2,974, 154 factories, 14 ships / 0 fleet mass, tech total 19, 1 starbases.
9. P6 Nairnian [Super Stealth] - 6 planets, pop 4,661, 214 factories, 13 ships / 0 fleet mass, tech total 13, 1 starbases.
10. P3 Romulans [Super Stealth / Balanced] - 4 planets, pop 6,207, 254 factories, 20 ships / 0 fleet mass, tech total 11, 1 starbases.
11. P11 Ubert [Super Stealth] - 4 planets, pop 4,575, 235 factories, 10 ships / 0 fleet mass, tech total 13, 1 starbases.

CHANGE SINCE TURN 20
-----------------------------
P7: planets +9, population +1,341, factories +63, ships +6, fleet mass +0, tech total +5.
P10: planets +10, population +1,756, factories +0, ships -4, fleet mass +0, tech total +8.
P9: planets +2, population +1,769, factories +13, ships +3, fleet mass +0, tech total +3.
P4: planets +0, population +1,803, factories +125, ships +20, fleet mass +0, tech total +5.
P8: planets +1, population +2,271, factories +258, ships +0, fleet mass +0, tech total +1.
P2: planets +2, population +1,850, factories +125, ships +15, fleet mass +0, tech total +4.
P1: planets +0, population +681, factories +1, ships +0, fleet mass +0, tech total +0.
P5: planets +1, population +1,064, factories +93, ships +6, fleet mass +0, tech total +0.
P6: planets +3, population +1,819, factories +72, ships +1, fleet mass +0, tech total +4.
P3: planets +0, population +2,294, factories +122, ships +13, fleet mass +0, tech total +3.
P11: planets +2, population +1,856, factories +113, ships -3, fleet mass +0, tech total +2.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P7 with 45 planets.
- Population: P3 with 6,207.
- Industry: P8 with 537 factories.
- Fleet by mass: P7 with 0.
- Technology: P7 with tech total 24.

MOMENTUM / RISK
---------------
- Current leader: P7 Felite.
- Current last place: P11 Ubert.
- P10 is materially behind the leader (<60% of leader observer score).
- P9 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P8 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P5 is materially behind the leader (<60% of leader observer score).
- P6 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P11 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
