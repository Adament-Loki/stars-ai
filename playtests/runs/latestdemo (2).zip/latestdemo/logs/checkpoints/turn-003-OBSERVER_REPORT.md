```
Stars! AI Observer Report - Turn 3 / Year 2403
==================================================================

EXECUTIVE SUMMARY
-----------------
The game remains competitive; P5 Humanoid currently has a narrow lead. Observer score gap over second place: 4.5%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P5 Humanoid [Jack of All Trades / Balanced] - 2 planets, pop 360, 12 factories, 6 ships / 0 fleet mass, tech total 19, 1 starbases.
2. P1 SuperRabits [Interstellar Traveler / Balanced] - 3 planets, pop 398, 16 factories, 4 ships / 0 fleet mass, tech total 14, 2 starbases.
3. P8 Picardi [Inner Strength] - 1 planets, pop 266, 22 factories, 1 ships / 0 fleet mass, tech total 19, 1 starbases.
4. P9 Hawk [Packet Physics] - 3 planets, pop 305, 14 factories, 1 ships / 0 fleet mass, tech total 11, 2 starbases.
5. P4 Kilingons [War Monger / Balanced] - 1 planets, pop 380, 12 factories, 2 ships / 0 fleet mass, tech total 14, 1 starbases.
6. P3 Romulans [Super Stealth / Balanced] - 2 planets, pop 405, 10 factories, 2 ships / 0 fleet mass, tech total 7, 1 starbases.
7. P2 S2 [Inner Strength / Balanced] - 2 planets, pop 405, 10 factories, 1 ships / 0 fleet mass, tech total 7, 1 starbases.
8. P6 Nairnian [Super Stealth] - 1 planets, pop 333, 10 factories, 4 ships / 0 fleet mass, tech total 6, 1 starbases.
9. P11 Ubert [Super Stealth] - 1 planets, pop 333, 10 factories, 4 ships / 0 fleet mass, tech total 6, 1 starbases.
10. P7 Felite [Hyper Expansion] - 1 planets, pop 351, 25 factories, 3 ships / 0 fleet mass, tech total 2, 1 starbases.
11. P10 Tritizoid [Alternate Reality] - 1 planets, pop 370, 0 factories, 1 ships / 0 fleet mass, tech total 2, 1 starbases.

CHANGE SINCE TURN 0
-----------------------------
P5: planets +1, population +110, factories +0, ships +0, fleet mass +0, tech total +0.
P1: planets +1, population +98, factories +2, ships -1, fleet mass +0, tech total +0.
P8: planets +0, population +91, factories +12, ships -1, fleet mass +0, tech total +0.
P9: planets +1, population +95, factories +0, ships -2, fleet mass +0, tech total +0.
P4: planets +0, population +130, factories +0, ships +0, fleet mass +0, tech total +0.
P3: planets +1, population +155, factories +0, ships -1, fleet mass +0, tech total +1.
P2: planets +1, population +155, factories +0, ships -1, fleet mass +0, tech total +0.
P6: planets +0, population +83, factories +0, ships +0, fleet mass +0, tech total +0.
P11: planets +0, population +83, factories +0, ships +0, fleet mass +0, tech total +0.
P7: planets +0, population +101, factories +15, ships -1, fleet mass +0, tech total +0.
P10: planets +0, population +120, factories +0, ships -1, fleet mass +0, tech total +0.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P1 with 3 planets.
- Population: P3 with 405.
- Industry: P7 with 25 factories.
- Fleet by mass: P5 with 0.
- Technology: P5 with tech total 19.

MOMENTUM / RISK
---------------
- Current leader: P5 Humanoid.
- Current last place: P10 Tritizoid.
- P3 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P6 is materially behind the leader (<60% of leader observer score).
- P11 is materially behind the leader (<60% of leader observer score).
- P7 is materially behind the leader (<60% of leader observer score).
- P10 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
