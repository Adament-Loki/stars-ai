```
Stars! AI Observer Report - Turn 20 / Year 2420
==================================================================

EXECUTIVE SUMMARY
-----------------
P7 Felite has a clear lead. Observer score gap over second place: 151.4%.
Likely fighting has begun: major fleet losses are visible, although no enemy planet changed hands in this window.

CURRENT STANDINGS
-----------------
1. P7 Felite [Hyper Expansion] - 36 planets, pop 1,988, 155 factories, 13 ships / 0 fleet mass, tech total 19, 1 starbases.
2. P10 Tritizoid [Alternate Reality] - 9 planets, pop 3,016, 0 factories, 10 ships / 0 fleet mass, tech total 15, 9 starbases.
3. P9 Hawk [Packet Physics] - 11 planets, pop 2,062, 47 factories, 5 ships / 0 fleet mass, tech total 15, 2 starbases.
4. P1 SuperRabits [Interstellar Traveler / Balanced] - 10 planets, pop 1,683, 25 factories, 5 ships / 0 fleet mass, tech total 18, 2 starbases.
5. P4 Kilingons [War Monger / Balanced] - 4 planets, pop 3,973, 215 factories, 10 ships / 0 fleet mass, tech total 14, 1 starbases.
6. P8 Picardi [Inner Strength] - 2 planets, pop 2,644, 279 factories, 2 ships / 0 fleet mass, tech total 19, 1 starbases.
7. P5 Humanoid [Jack of All Trades / Balanced] - 5 planets, pop 1,910, 61 factories, 8 ships / 0 fleet mass, tech total 19, 1 starbases.
8. P2 S2 [Inner Strength / Balanced] - 5 planets, pop 4,003, 136 factories, 9 ships / 0 fleet mass, tech total 10, 1 starbases.
9. P3 Romulans [Super Stealth / Balanced] - 4 planets, pop 3,913, 132 factories, 7 ships / 0 fleet mass, tech total 8, 1 starbases.
10. P6 Nairnian [Super Stealth] - 3 planets, pop 2,842, 142 factories, 12 ships / 0 fleet mass, tech total 9, 1 starbases.
11. P11 Ubert [Super Stealth] - 2 planets, pop 2,719, 122 factories, 13 ships / 0 fleet mass, tech total 11, 1 starbases.

CHANGE SINCE TURN 15
-----------------------------
P7: planets +12, population +817, factories +44, ships +3, fleet mass +0, tech total +6.
P10: planets +6, population +1,310, factories +0, ships +6, fleet mass +0, tech total +7.
P9: planets +4, population +940, factories +20, ships +0, fleet mass +0, tech total +2.
P1: planets +3, population +549, factories +2, ships -3, fleet mass +0, tech total +3.
P4: planets +0, population +1,857, factories +114, ships +9, fleet mass +0, tech total +0.
P8: planets +1, population +1,224, factories +107, ships +1, fleet mass +0, tech total +0.
P5: planets +0, population +692, factories +49, ships +1, fleet mass +0, tech total +0.
P2: planets +1, population +1,878, factories +78, ships +7, fleet mass +0, tech total +2.
P3: planets +0, population +1,855, factories +84, ships +5, fleet mass +0, tech total +1.
P6: planets +1, population +1,371, factories +89, ships -1, fleet mass +0, tech total +1.
P11: planets +0, population +1,295, factories +95, ships +0, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- P1 suffered a major net fleet loss during Turn 20 / Year 2420 (ships 8->5; fleets 8->5; net loss 3 ships). Observed fleet change: fleet ID 1 disappeared (1 ships; last seen at (2106, 1182)); fleet ID 7 disappeared (1 ships; last seen at (1740, 1238)); fleet ID 8 disappeared (1 ships; last seen at (1724, 1135)). Cause is not decoded.

WHO IS STRONGEST?
-----------------
- Territory: P7 with 36 planets.
- Population: P2 with 4,003.
- Industry: P8 with 279 factories.
- Fleet by mass: P7 with 0.
- Technology: P7 with tech total 19.

MOMENTUM / RISK
---------------
- Current leader: P7 Felite.
- Current last place: P11 Ubert.
- P10 is materially behind the leader (<60% of leader observer score).
- P9 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P8 is materially behind the leader (<60% of leader observer score).
- P5 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P6 is materially behind the leader (<60% of leader observer score).
- P11 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
