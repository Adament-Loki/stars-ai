```
Stars! AI Observer Report - Turn 35 / Year 2435
==================================================================

EXECUTIVE SUMMARY
-----------------
P7 Felite has a clear lead. Observer score gap over second place: 87.6%.
No clear evidence of player-vs-player fighting yet; expansion and buildup still dominate.

CURRENT STANDINGS
-----------------
1. P7 Felite [Hyper Expansion] - 64 planets, pop 9,450, 568 factories, 13 ships / 0 fleet mass, tech total 33, 1 starbases.
2. P10 Tritizoid [Alternate Reality] - 25 planets, pop 8,772, 0 factories, 7 ships / 0 fleet mass, tech total 33, 25 starbases.
3. P6 Nairnian [Super Stealth] - 13 planets, pop 7,495, 676 factories, 9 ships / 0 fleet mass, tech total 24, 1 starbases.
4. P8 Picardi [Inner Strength] - 4 planets, pop 9,248, 1025 factories, 2 ships / 0 fleet mass, tech total 30, 1 starbases.
5. P9 Hawk [Packet Physics] - 19 planets, pop 8,854, 119 factories, 24 ships / 0 fleet mass, tech total 22, 2 starbases.
6. P4 Kilingons [War Monger / Balanced] - 5 planets, pop 10,583, 603 factories, 30 ships / 0 fleet mass, tech total 30, 1 starbases.
7. P3 Romulans [Super Stealth / Balanced] - 7 planets, pop 10,395, 555 factories, 40 ships / 0 fleet mass, tech total 27, 1 starbases.
8. P2 S2 [Inner Strength / Balanced] - 9 planets, pop 9,282, 511 factories, 32 ships / 0 fleet mass, tech total 23, 1 starbases.
9. P5 Humanoid [Jack of All Trades / Balanced] - 9 planets, pop 6,644, 401 factories, 38 ships / 0 fleet mass, tech total 24, 1 starbases.
10. P11 Ubert [Super Stealth] - 5 planets, pop 7,068, 676 factories, 12 ships / 0 fleet mass, tech total 25, 1 starbases.
11. P1 SuperRabits [Interstellar Traveler / Balanced] - 10 planets, pop 4,673, 96 factories, 5 ships / 0 fleet mass, tech total 19, 2 starbases.

CHANGE SINCE TURN 30
-----------------------------
P7: planets +8, population +3,934, factories +222, ships -6, fleet mass +0, tech total +6.
P10: planets +4, population +2,147, factories +0, ships -1, fleet mass +0, tech total +6.
P6: planets +3, population +1,252, factories +247, ships -4, fleet mass +0, tech total +7.
P8: planets +0, population +1,997, factories +203, ships +0, fleet mass +0, tech total +8.
P9: planets +3, population +2,663, factories +47, ships +10, fleet mass +0, tech total +1.
P4: planets +0, population +2,368, factories +138, ships +0, fleet mass +0, tech total +6.
P3: planets +3, population +2,007, factories +176, ships +3, fleet mass +0, tech total +12.
P2: planets +1, population +1,854, factories +125, ships +1, fleet mass +0, tech total +5.
P5: planets +3, population +2,273, factories +125, ships +7, fleet mass +0, tech total +5.
P11: planets +1, population +1,069, factories +178, ships -2, fleet mass +0, tech total +9.
P1: planets +0, population +1,353, factories +64, ships +0, fleet mass +0, tech total +1.

WAR & CONTACT
-------------
- No captures or major net fleet-loss events detected in this reporting window.

WHO IS STRONGEST?
-----------------
- Territory: P7 with 64 planets.
- Population: P4 with 10,583.
- Industry: P8 with 1025 factories.
- Fleet by mass: P7 with 0.
- Technology: P7 with tech total 33.

MOMENTUM / RISK
---------------
- Current leader: P7 Felite.
- Current last place: P1 SuperRabits.
- P10 is materially behind the leader (<60% of leader observer score).
- P6 is materially behind the leader (<60% of leader observer score).
- P8 is materially behind the leader (<60% of leader observer score).
- P9 is materially behind the leader (<60% of leader observer score).
- P4 is materially behind the leader (<60% of leader observer score).
- P3 is materially behind the leader (<60% of leader observer score).
- P2 is materially behind the leader (<60% of leader observer score).
- P5 is materially behind the leader (<60% of leader observer score).
- P11 is materially behind the leader (<60% of leader observer score).
- P1 is materially behind the leader (<60% of leader observer score).

INTERPRETATION
--------------
Observer score is a transparent diagnostic composite, not the Stars! built-in score. Planet captures are strong evidence of war; abrupt fleet losses are treated as probable combat but can also reflect scrapping/merging until battle blocks are fully decoded.

```
