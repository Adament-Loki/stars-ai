STARS! AI approved-action review bundle

This is not a standalone game or replay directory. Review the prior 30-committed phase for native state, END_OF_TURN_APPROVED_ACTIONS.txt for the decision summary, and orders/GAME.x# for the exact staged orders.
